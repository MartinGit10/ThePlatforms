gdjs.Escena_32sin_32t_237tuloCode = {};


gdjs.Escena_32sin_32t_237tuloCode.eventsList0 = function(runtimeScene) {

};

gdjs.Escena_32sin_32t_237tuloCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.Escena_32sin_32t_237tuloCode.eventsList0(runtimeScene);

return;

}

gdjs['Escena_32sin_32t_237tuloCode'] = gdjs.Escena_32sin_32t_237tuloCode;
